import React, { useState } from 'react'

export default function TodoForm(props) {
    const [inputValue, setInputValue] = useState('');
    const handleSubmit = (event) => {
        event.preventDefault();
        props.onSubmit(inputValue);
        setInputValue('');
    }
  return (
      <form onSubmit={handleSubmit}>
        <h2>todoForm</h2>
        <input type='text' value={inputValue} onChange={e => setInputValue(e.target.value)} />
        <button type='submit'>Add</button>
    </form>
  )
}
