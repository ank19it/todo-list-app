import { useState } from 'react';
import './App.css';
import TodoForm from './TodoForm';
import TodoList from './TodoList';

function App() {
  const [todos, setTodos] = useState([]);
  const handleSubmit = (name) => {
    setTodos([...todos, {
      name, isComplete: false
    }]);
  }
  const handleChange = (index) => {
    const newTodos = [...todos];
    newTodos[index].isComplete = !newTodos[index].isComplete;
    setTodos(newTodos);
  }
  const handleDelete = (index) => {
    const newTodos = [...todos];
    newTodos.splice(index, 1);
    setTodos(newTodos);
  }
  return (
    <div className="App">
      <TodoForm onSubmit={handleSubmit} />
      <TodoList todos={todos} onChange={handleChange} onDelete={handleDelete} />
    </div>
  );
}

export default App;
