import React from 'react'

export default function TodoList(props) {
  return (
    <ul>
        {props.todos.map((todo, index) => (
            <li key={index}>
                <input type='checkbox' checked={todo.isComplete} onChange={() => props.onChange(index)} />
                {todo.name}
                <button onClick={() => props.onDelete(index)}>Delete</button>
            </li>
        ))}
    </ul>
  )
}
